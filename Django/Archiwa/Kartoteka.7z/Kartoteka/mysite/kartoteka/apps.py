from django.apps import AppConfig


class KartotekaConfig(AppConfig):
    name = 'kartoteka'
